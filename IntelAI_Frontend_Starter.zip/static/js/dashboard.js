// Frontend-only demo interactions. Connect these actions to your Flask/FastAPI endpoints.
const exportBtn = document.getElementById("exportBtn");
const predictionBtn = document.getElementById("predictionBtn");
const predictionMessage = document.getElementById("predictionMessage");
const viewAllBtn = document.getElementById("viewAllBtn");
const assistantBtn = document.getElementById("assistantBtn");

exportBtn?.addEventListener("click", () => {
  const summary = [
    "Intel.AI Attendance Intelligence - Demo Summary",
    "Attendance rate: 92.4%",
    "Students tracked: 1,248",
    "Students requiring review: 38",
    "",
    "Note: This is sample UI data. Connect your authorized backend data before use."
  ].join("\\n");
  const blob = new Blob([summary], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "intel-ai-demo-summary.txt";
  link.click();
  URL.revokeObjectURL(url);
});

predictionBtn?.addEventListener("click", () => {
  predictionMessage.textContent = "Demo insight: review students with repeated absences over the last 2 weeks. This is a placeholder, not a real ML prediction.";
});

viewAllBtn?.addEventListener("click", () => {
  document.getElementById("studentRows")?.scrollIntoView({ behavior: "smooth", block: "center" });
});

assistantBtn?.addEventListener("click", () => {
  alert("Sample prompt: Which students have shown a repeated absence pattern this week?\\n\\nConnect your AI assistant endpoint to enable real answers.");
});
