# Intel.AI Frontend Starter

A responsive dashboard UI starter for an attendance intelligence project. This is newly written frontend scaffolding, not a copy of the source repository's existing files.

## Files
- `templates/dashboard.html` — dashboard page, written for a Flask/Jinja app
- `static/css/dashboard.css` — responsive styles
- `static/js/dashboard.js` — small demo interactions (export summary, sample insight, assistant prompt)

## Add to a Flask project
Copy `templates/dashboard.html` into your Flask project's `templates/` directory and copy the `static/` folder into the project root.

Add a route in your existing Flask application (do not overwrite your current `app.py`):

```python
@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")
```

Ensure your existing app imports `render_template` from `flask`.

## Important
- All numbers and student records in this UI are illustrative demo content.
- The chart is a static illustration, not a live chart.
- The prediction and assistant actions are placeholders. Connect them to your existing API/model endpoints before claiming live functionality.
- Do not commit `.env` files, API keys, database files, student personal information, or trained model files unless you have a clear reason and authorization.
- If you adapt this for a team or another person's repository, check the project's license and give clear attribution. Only claim the work you actually contributed.
